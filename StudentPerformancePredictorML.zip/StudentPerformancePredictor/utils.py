import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False
import io
import base64
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import streamlit as st


class StudentPredictionUtils:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.label_encoders = None
        self.feature_names = None
        self.explainer = None
        self.background_data = None

    @st.cache_resource
    def load_model_assets(_self):
        """Load all model assets with caching"""
        try:
            # Load model
            with open('student_model.pkl', 'rb') as f:
                _self.model = pickle.load(f)

            # Load scaler
            with open('scaler.pkl', 'rb') as f:
                _self.scaler = pickle.load(f)

            # Load label encoders
            with open('label_encoders.pkl', 'rb') as f:
                _self.label_encoders = pickle.load(f)

            # Load feature names
            with open('feature_names.pkl', 'rb') as f:
                _self.feature_names = pickle.load(f)

            # Load background data for SHAP
            df = pd.read_csv('StudentsPerformance.csv')
            df['target'] = (df['math score'] >= 60).astype(int)
            X = df.drop(['math score', 'target'], axis=1)

            # Encode categorical variables
            categorical_columns = ['gender', 'race/ethnicity', 'parental level of education',
                                   'lunch', 'test preparation course']

            for col in categorical_columns:
                X[col] = _self.label_encoders[col].transform(X[col])

            # Scale features
            X_scaled = _self.scaler.transform(X)
            _self.background_data = pd.DataFrame(
                X_scaled, columns=_self.feature_names)

            # Create SHAP explainer
            if HAS_SHAP:
                _self.explainer = shap.Explainer(
                    _self.model, _self.background_data.sample(100))
            else:
                _self.explainer = None

            return True

        except Exception as e:
            st.error(f"Error loading model assets: {e}")
            return False

    def preprocess_input(self, input_data):
        """Preprocess user input for prediction"""
        try:
            # Create DataFrame from input
            df = pd.DataFrame([input_data])

            # Encode categorical variables
            categorical_columns = ['gender', 'race/ethnicity', 'parental level of education',
                                   'lunch', 'test preparation course']

            for col in categorical_columns:
                if col in df.columns:
                    df[col] = self.label_encoders[col].transform(df[col])

            # Scale features
            scaled_data = self.scaler.transform(df)
            return pd.DataFrame(scaled_data, columns=self.feature_names)

        except Exception as e:
            st.error(f"Error preprocessing input: {e}")
            return None

    def make_prediction(self, processed_input):
        """Make prediction and return result with confidence"""
        try:
            # Make prediction
            prediction = self.model.predict(processed_input)[0]
            prediction_proba = self.model.predict_proba(processed_input)[0]

            # Get confidence score
            confidence = max(prediction_proba) * 100

            # Convert to readable format
            result = "Pass" if prediction == 1 else "Fail"

            return result, confidence, prediction_proba

        except Exception as e:
            st.error(f"Error making prediction: {e}")
            return None, None, None

    def get_shap_explanation(self, processed_input):
        """Get SHAP explanation for the prediction"""
        if not HAS_SHAP or self.explainer is None:
            # Fallback: use feature importances from the model
            try:
                if hasattr(self.model, 'feature_importances_'):
                    importances = self.model.feature_importances_
                    feature_contributions = []
                    for i, feature in enumerate(self.feature_names):
                        contribution = importances[i] * \
                            processed_input.iloc[0, i]
                        feature_contributions.append({
                            'feature': feature,
                            'contribution': contribution,
                            'value': processed_input.iloc[0, i]
                        })

                    # Sort by absolute contribution
                    feature_contributions.sort(
                        key=lambda x: abs(x['contribution']), reverse=True)
                    return feature_contributions, None
                else:
                    # Generic fallback for models without feature importances
                    feature_contributions = []
                    for i, feature in enumerate(self.feature_names):
                        # Simple contribution based on feature value
                        # Arbitrary scaling
                        contribution = processed_input.iloc[0, i] * 0.1
                        feature_contributions.append({
                            'feature': feature,
                            'contribution': contribution,
                            'value': processed_input.iloc[0, i]
                        })

                    feature_contributions.sort(
                        key=lambda x: abs(x['contribution']), reverse=True)
                    return feature_contributions, None

            except Exception as e:
                st.error(f"Error generating explanation: {e}")
                return [], None

        try:
            # Calculate SHAP values
            shap_values = self.explainer(processed_input)

            # Get feature contributions
            feature_contributions = []
            for i, feature in enumerate(self.feature_names):
                contribution_raw = shap_values[0].values[i]
                # If contribution_raw is an array, reduce to scalar
                if hasattr(contribution_raw, "__len__") and not isinstance(contribution_raw, str):
                    # Use sum of absolute values as scalar contribution
                    contribution = float(np.sum(np.abs(contribution_raw)))
                else:
                    contribution = float(contribution_raw)
                feature_contributions.append({
                    'feature': feature,
                    'contribution': contribution,
                    'value': processed_input.iloc[0, i]
                })

            # Sort by absolute contribution
            feature_contributions.sort(
                key=lambda x: abs(x['contribution']), reverse=True)

            return feature_contributions, shap_values

        except Exception as e:
            st.error(f"Error generating SHAP explanation: {e}")
            return [], None

    def generate_recommendations(self, input_data, feature_contributions):
        """Generate personalized recommendations based on input and SHAP analysis"""
        recommendations = []

        # Extract input values
        reading_score = input_data.get('reading score', 0)
        writing_score = input_data.get('writing score', 0)
        test_prep = input_data.get('test preparation course', 'none')
        lunch = input_data.get('lunch', 'standard')
        parental_education = input_data.get(
            'parental level of education', 'high school')

        # Analyze top negative contributors
        negative_contributors = [
            fc for fc in feature_contributions if fc['contribution'] < 0]

        # Reading score recommendations
        if reading_score < 60:
            recommendations.append({
                'area': 'Reading Skills',
                'issue': 'Low reading score is negatively affecting performance',
                'recommendation': 'Focus on improving reading comprehension and vocabulary',
                'resources': [
                    ('Khan Academy Reading',
                     'https://www.khanacademy.org/humanities/reading-comprehension'),
                    ('ReadWorks Practice', 'https://www.readworks.org/'),
                    ('Coursera Reading Skills',
                     'https://www.coursera.org/learn/reading-skills')
                ]
            })

        # Writing score recommendations
        if writing_score < 60:
            recommendations.append({
                'area': 'Writing Skills',
                'issue': 'Low writing score is impacting overall performance',
                'recommendation': 'Practice essay writing and grammar fundamentals',
                'resources': [
                    ('Grammarly Writing Guide', 'https://www.grammarly.com/blog/'),
                    ('Purdue OWL Writing Lab',
                     'https://owl.purdue.edu/owl/purdue_owl.html'),
                    ('Khan Academy Writing',
                     'https://www.khanacademy.org/humanities/grammar')
                ]
            })

        # Test preparation recommendations
        if test_prep == 'none':
            recommendations.append({
                'area': 'Test Preparation',
                'issue': 'No test preparation course completed',
                'recommendation': 'Consider enrolling in a test preparation course',
                'resources': [
                    ('Khan Academy SAT Prep', 'https://www.khanacademy.org/sat'),
                    ('College Board Practice',
                     'https://collegereadiness.collegeboard.org/'),
                    ('Princeton Review Tips',
                     'https://www.princetonreview.com/college/test-prep')
                ]
            })

        # Parental engagement recommendations
        if parental_education in ['high school', 'some high school']:
            recommendations.append({
                'area': 'Family Support',
                'issue': 'Parental education level may limit academic support',
                'recommendation': 'Seek additional academic support and mentorship',
                'resources': [
                    ('Parent-Teacher Resources',
                     'https://www.pta.org/home/family-resources'),
                    ('Academic Tutoring Services', 'https://www.tutor.com/'),
                    ('Community College Resources',
                     'https://www.aacc.nche.edu/students-parents/')
                ]
            })

        # Lunch program recommendations (socioeconomic factors)
        if lunch == 'free/reduced':
            recommendations.append({
                'area': 'Additional Support',
                'issue': 'Socioeconomic factors may impact academic resources',
                'recommendation': 'Explore free educational resources and support programs',
                'resources': [
                    ('Free Educational Resources', 'https://www.khanacademy.org/'),
                    ('Library Study Programs',
                     'https://www.ala.org/tools/programming'),
                    ('Community Support Services',
                     'https://www.benefits.gov/categories/Education%20and%20Training')
                ]
            })

        # General study recommendations based on SHAP analysis
        if len(negative_contributors) > 0:
            top_negative = negative_contributors[0]
            recommendations.append({
                'area': 'Priority Focus Area',
                'issue': f'{top_negative["feature"]} is the strongest negative factor',
                'recommendation': f'Focus primarily on improving {top_negative["feature"]}',
                'resources': [
                    ('Study Skills Guide',
                     'https://www.khanacademy.org/college-careers-more/study-skills'),
                    ('Time Management Tips',
                     'https://www.coursera.org/learn/learning-how-to-learn'),
                    ('Academic Success Strategies',
                     'https://www.edx.org/learn/study-skills')
                ]
            })

        return recommendations

    def create_shap_plot(self, shap_values, processed_input):
        """Create SHAP waterfall plot as image"""
        if not HAS_SHAP or shap_values is None:
            return None

        try:
            fig, ax = plt.subplots(figsize=(10, 6))

            # Create waterfall plot
            shap.plots.waterfall(shap_values[0], show=False)

            # Convert to base64 for display
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', bbox_inches='tight', dpi=150)
            buffer.seek(0)

            img_base64 = base64.b64encode(buffer.read()).decode()
            plt.close()

            return img_base64

        except Exception as e:
            st.error(f"Error creating SHAP plot: {e}")
            return None

    def generate_pdf_report(self, input_data, prediction, confidence, recommendations, student_name="", student_id=""):
        """Generate PDF report"""
        try:
            buffer = io.BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=letter)
            styles = getSampleStyleSheet()
            story = []

            # Title
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                textColor=colors.darkblue,
                alignment=1  # Center alignment
            )
            story.append(
                Paragraph("Student Performance Prediction Report", title_style))
            story.append(Spacer(1, 20))

            # Student Details
            story.append(Paragraph("Student Details", styles['Heading2']))
            student_details_data = [
                ['Student Name', student_name if student_name else 'N/A'],
                ['Student ID', student_id if student_id else 'N/A']
            ]
            student_details_table = Table(
                student_details_data, colWidths=[2*inch, 3*inch])
            student_details_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(student_details_table)
            story.append(Spacer(1, 20))

            # Prediction Results
            story.append(Paragraph("Prediction Results", styles['Heading2']))

            prediction_data = [
                ['Prediction', prediction],
                ['Confidence', f"{confidence:.1f}%"],
                ['Date', pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S")]
            ]

            prediction_table = Table(
                prediction_data, colWidths=[2*inch, 3*inch])
            prediction_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))

            story.append(prediction_table)
            story.append(Spacer(1, 20))

            # Student Information
            story.append(Paragraph("Student Information", styles['Heading2']))

            student_data = [
                ['Gender', input_data.get('gender', 'N/A')],
                ['Race/Ethnicity', input_data.get('race/ethnicity', 'N/A')],
                ['Parental Education', input_data.get(
                    'parental level of education', 'N/A')],
                ['Lunch Program', input_data.get('lunch', 'N/A')],
                ['Test Preparation', input_data.get(
                    'test preparation course', 'N/A')],
                ['Reading Score', str(input_data.get('reading score', 'N/A'))],
                ['Writing Score', str(input_data.get('writing score', 'N/A'))]
            ]

            student_table = Table(student_data, colWidths=[2*inch, 3*inch])
            student_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))

            story.append(student_table)
            story.append(Spacer(1, 20))

            # Recommendations
            story.append(
                Paragraph("Personalized Recommendations", styles['Heading2']))

            for i, rec in enumerate(recommendations, 1):
                story.append(
                    Paragraph(f"{i}. {rec['area']}", styles['Heading3']))
                story.append(
                    Paragraph(f"Issue: {rec['issue']}", styles['Normal']))
                story.append(
                    Paragraph(f"Recommendation: {rec['recommendation']}", styles['Normal']))

                if rec['resources']:
                    story.append(Paragraph("Resources:", styles['Normal']))
                    for resource_name, resource_url in rec['resources']:
                        story.append(
                            Paragraph(f"• {resource_name}: {resource_url}", styles['Normal']))

                story.append(Spacer(1, 12))

            # Build PDF
            doc.build(story)
            buffer.seek(0)

            return buffer.getvalue()

        except Exception as e:
            st.error(f"Error generating PDF report: {e}")
            return None


def get_feature_options():
    """Get options for categorical features"""
    return {
        'gender': ['female', 'male'],
        'race/ethnicity': ['group A', 'group B', 'group C', 'group D'],
        'parental level of education': [
            'high school', 'some college', 'associate\'s degree',
            'bachelor\'s degree', 'master\'s degree'
        ],
        'lunch': ['standard', 'free/reduced'],
        'test preparation course': ['none', 'completed']
    }
