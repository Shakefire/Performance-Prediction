import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from utils import StudentPredictionUtils, get_feature_options, HAS_SHAP
import base64

# Page configuration
st.set_page_config(
    page_title="Student Performance Predictor",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize utilities


@st.cache_resource
def load_utils():
    utils = StudentPredictionUtils()
    success = utils.load_model_assets()
    return utils, success


def main():
    st.title("🎓 Student Performance Prediction System")
    st.markdown("---")

    # Load model assets
    utils, success = load_utils()

    if not success:
        st.error(
            "Failed to load model assets. Please ensure all model files are present.")
        st.stop()

    # Sidebar for input
    st.sidebar.header("📝 Student Information")
    st.sidebar.markdown("Please provide the following information:")

    # Get feature options
    feature_options = get_feature_options()

    # Collect user input
    input_data = {}

    # New inputs for student name and ID
    input_data['student_name'] = st.sidebar.text_input(
        "Student Name", value="")
    input_data['student_id'] = st.sidebar.text_input("Student ID", value="")

    # Categorical inputs
    input_data['gender'] = st.sidebar.selectbox(
        "Gender",
        options=feature_options['gender']
    )

    input_data['race/ethnicity'] = st.sidebar.selectbox(
        "Race/Ethnicity",
        options=feature_options['race/ethnicity']
    )

    input_data['parental level of education'] = st.sidebar.selectbox(
        "Parental Level of Education",
        options=feature_options['parental level of education']
    )

    input_data['lunch'] = st.sidebar.selectbox(
        "Lunch Program",
        options=feature_options['lunch'],
        help="Standard or Free/Reduced lunch program"
    )

    input_data['test preparation course'] = st.sidebar.selectbox(
        "Test Preparation Course",
        options=feature_options['test preparation course'],
        help="Whether student completed test preparation course"
    )

    # Numerical inputs
    input_data['reading score'] = st.sidebar.slider(
        "Reading Score",
        min_value=0,
        max_value=100,
        value=70,
        help="Student's reading score (0-100)"
    )

    input_data['writing score'] = st.sidebar.slider(
        "Writing Score",
        min_value=0,
        max_value=100,
        value=70,
        help="Student's writing score (0-100)"
    )

    # Predict button
    predict_button = st.sidebar.button("🔮 Predict Performance", type="primary")

    # Main content area
    if predict_button:
        # Prepare model input by excluding student_name and student_id
        model_input_data = {k: v for k, v in input_data.items() if k not in [
            'student_name', 'student_id']}

        # Process input
        processed_input = utils.preprocess_input(model_input_data)

        if processed_input is not None:
            # Make prediction
            prediction, confidence, prediction_proba = utils.make_prediction(
                processed_input)

            if prediction is not None:
                # Display prediction results
                col1, col2, col3 = st.columns(3)

                with col1:
                    st.metric(
                        "🎯 Prediction",
                        prediction,
                        delta=None
                    )

                with col2:
                    st.metric(
                        "📊 Confidence",
                        f"{confidence:.1f}%",
                        delta=None
                    )

                with col3:
                    pass_prob = prediction_proba[1] * 100
                    st.metric(
                        "✅ Pass Probability",
                        f"{pass_prob:.1f}%",
                        delta=None
                    )

                # Create probability visualization
                fig = go.Figure(data=[
                    go.Bar(
                        x=['Fail', 'Pass'],
                        y=[prediction_proba[0] * 100, prediction_proba[1] * 100],
                        marker_color=['red', 'green']
                    )
                ])

                fig.update_layout(
                    title="Prediction Probabilities",
                    xaxis_title="Outcome",
                    yaxis_title="Probability (%)",
                    showlegend=False
                )

                st.plotly_chart(fig, use_container_width=True)

                # SHAP Explanation
                st.markdown("---")
                st.subheader("🔍 Model Explanation")

                # Check if SHAP is available
                if not HAS_SHAP:
                    st.info(
                        "📊 Using feature importance analysis (SHAP analysis unavailable)")
                else:
                    st.info("📊 Using SHAP analysis for detailed explanations")

                feature_contributions, shap_values = utils.get_shap_explanation(
                    processed_input)

                if feature_contributions:
                    # Create SHAP visualization
                    features = [fc['feature'] for fc in feature_contributions]
                    contributions = [fc['contribution']
                                     for fc in feature_contributions]

                    # Create horizontal bar chart for feature contributions
                    fig_shap = go.Figure(data=[
                        go.Bar(
                            y=features,
                            x=contributions,
                            orientation='h',
                            marker_color=['red' if x <
                                          0 else 'green' for x in contributions]
                        )
                    ])

                    fig_shap.update_layout(
                        title="Feature Contributions to Prediction",
                        xaxis_title="SHAP Value (Impact on Prediction)",
                        yaxis_title="Features",
                        showlegend=False
                    )

                    st.plotly_chart(fig_shap, use_container_width=True)

                    # Display top contributors
                    st.subheader("📊 Key Factors Analysis")

                    col1, col2 = st.columns(2)

                    with col1:
                        st.write("**Top Positive Factors:**")
                        positive_factors = [
                            fc for fc in feature_contributions if fc['contribution'] > 0][:3]
                        for factor in positive_factors:
                            st.write(
                                f"• {factor['feature']}: +{factor['contribution']:.3f}")

                    with col2:
                        st.write("**Top Negative Factors:**")
                        negative_factors = [
                            fc for fc in feature_contributions if fc['contribution'] < 0][:3]
                        for factor in negative_factors:
                            st.write(
                                f"• {factor['feature']}: {factor['contribution']:.3f}")

                # Personalized Recommendations
                st.markdown("---")
                st.subheader("🎓 Personalized Recommendations")

                recommendations = utils.generate_recommendations(
                    input_data, feature_contributions)

                if recommendations:
                    for i, rec in enumerate(recommendations):
                        with st.expander(f"📚 {rec['area']}", expanded=True):
                            st.warning(f"**Issue:** {rec['issue']}")
                            st.info(
                                f"**Recommendation:** {rec['recommendation']}")

                            if rec['resources']:
                                st.write("**Helpful Resources:**")
                                for resource_name, resource_url in rec['resources']:
                                    st.write(
                                        f"• [{resource_name}]({resource_url})")

                # Generate PDF Report
                st.markdown("---")
                st.subheader("📄 Download Report")

                if st.button("📋 Generate PDF Report"):
                    pdf_data = utils.generate_pdf_report(
                        input_data, prediction, confidence, recommendations,
                        student_name=input_data.get('student_name', ''),
                        student_id=input_data.get('student_id', '')
                    )
                    st.write(f"PDF data type: {type(pdf_data)}; length: {len(pdf_data) if pdf_data else 'None'}")  # Debug output
                    if pdf_data:
                        import base64
                        b64_pdf = base64.b64encode(pdf_data).decode('utf-8')
                        href = f'<a href="data:application/pdf;base64,{b64_pdf}" download="student_performance_report_{pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")}.pdf">⬇️ Download PDF Report</a>'
                        st.markdown(href, unsafe_allow_html=True)
                        st.success("PDF report generated successfully!")


                # Student Input Summary
                st.markdown("---")
                st.subheader("📋 Input Summary")

                input_df = pd.DataFrame([input_data])
                st.dataframe(input_df, use_container_width=True)

    else:
        # Default welcome message
        st.markdown("""
        ## Welcome to the Student Performance Prediction System! 🎯
        
        This application uses machine learning to predict student performance based on various factors
        and provides personalized recommendations for improvement.
        
        ### How to use:
        1. **Fill in the student information** in the sidebar
        2. **Click "Predict Performance"** to get results
        3. **Review the prediction** and confidence score
        4. **Analyze the SHAP explanations** to understand key factors
        5. **Read personalized recommendations** for improvement
        6. **Download a PDF report** with all the analysis
        
        ### Features:
        - 🤖 **ML-Powered Predictions**: Uses advanced machine learning algorithms
        - 🔍 **SHAP Explainability**: Understand why predictions are made
        - 📊 **Interactive Visualizations**: Clear charts and graphs
        - 🎓 **Personalized Recommendations**: Tailored study suggestions
        - 📱 **User-Friendly Interface**: Easy-to-use web application
        - 📄 **PDF Reports**: Downloadable comprehensive reports
        
        ### Get Started:
        Please provide the student information in the sidebar to begin the analysis.
        """)

        # Display sample data structure
        st.markdown("---")
        st.subheader("📊 Sample Data Structure")

        sample_data = {
            'gender': 'female',
            'race/ethnicity': 'group B',
            'parental level of education': 'bachelor\'s degree',
            'lunch': 'standard',
            'test preparation course': 'completed',
            'reading score': 85,
            'writing score': 82
        }

        sample_df = pd.DataFrame([sample_data])
        st.dataframe(sample_df, use_container_width=True)


if __name__ == "__main__":
    main()
