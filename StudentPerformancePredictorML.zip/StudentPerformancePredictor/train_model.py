import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score, classification_report
import xgboost as xgb
import pickle
try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False
    print("Warning: SHAP not available. Model explanations will be limited.")
import os

class StudentPerformancePredictor:
    def __init__(self):
        self.models = {}
        self.model_scores = {}
        self.best_model = None
        self.best_model_name = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_names = []
        self.X_train = None
        self.y_train = None
        
    def load_and_explore_data(self, file_path):
        """Load and explore the dataset"""
        print("Loading and exploring data...")
        try:
            self.df = pd.read_csv(file_path)
            print(f"Dataset shape: {self.df.shape}")
            print("\nFirst few rows:")
            print(self.df.head())
            print("\nDataset info:")
            print(self.df.info())
            print("\nMissing values:")
            print(self.df.isnull().sum())
            print("\nBasic statistics:")
            print(self.df.describe())
            return self.df
        except Exception as e:
            print(f"Error loading data: {e}")
            return None
    
    def preprocess_data(self):
        """Preprocess the data with encoding and scaling"""
        print("\nPreprocessing data...")
        
        # Create target variable: math score >= 60 = 1 (pass), else 0 (fail)
        self.df['target'] = (self.df['math score'] >= 60).astype(int)
        
        # Separate features and target
        X = self.df.drop(['math score', 'target'], axis=1)
        y = self.df['target']
        
        # Encode categorical variables
        categorical_columns = ['gender', 'race/ethnicity', 'parental level of education', 
                             'lunch', 'test preparation course']
        
        for col in categorical_columns:
            le = LabelEncoder()
            X[col] = le.fit_transform(X[col])
            self.label_encoders[col] = le
        
        # Store feature names
        self.feature_names = X.columns.tolist()
        
        # Scale numerical features
        X_scaled = self.scaler.fit_transform(X)
        X_scaled = pd.DataFrame(X_scaled, columns=self.feature_names)
        
        # Train-test split
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42, stratify=y
        )
        
        print(f"Training set shape: {self.X_train.shape}")
        print(f"Test set shape: {self.X_test.shape}")
        print(f"Target distribution - Train: {self.y_train.value_counts().to_dict()}")
        print(f"Target distribution - Test: {self.y_test.value_counts().to_dict()}")
        
        return self.X_train, self.X_test, self.y_train, self.y_test
    
    def exploratory_data_analysis(self):
        """Generate 5 key visualizations"""
        print("\nGenerating EDA visualizations...")
        
        plt.style.use('default')
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # 1. Countplot of parental level of education vs pass/fail
        ax1 = axes[0, 0]
        education_target = pd.crosstab(self.df['parental level of education'], self.df['target'])
        education_target.plot(kind='bar', ax=ax1, color=['red', 'green'])
        ax1.set_title('Parental Level of Education vs Pass/Fail')
        ax1.set_xlabel('Parental Level of Education')
        ax1.set_ylabel('Count')
        ax1.legend(['Fail', 'Pass'])
        ax1.tick_params(axis='x', rotation=45)
        
        # 2. Histogram of reading score
        ax2 = axes[0, 1]
        ax2.hist(self.df['reading score'], bins=20, color='skyblue', edgecolor='black')
        ax2.set_title('Distribution of Reading Scores')
        ax2.set_xlabel('Reading Score')
        ax2.set_ylabel('Frequency')
        
        # 3. Boxplot of writing score vs pass/fail
        ax3 = axes[0, 2]
        self.df.boxplot(column='writing score', by='target', ax=ax3)
        ax3.set_title('Writing Score vs Pass/Fail')
        ax3.set_xlabel('Target (0=Fail, 1=Pass)')
        ax3.set_ylabel('Writing Score')
        
        # 4. Heatmap of feature correlations
        ax4 = axes[1, 0]
        # Create correlation matrix for numerical features
        numerical_df = self.df[['math score', 'reading score', 'writing score', 'target']]
        corr_matrix = numerical_df.corr()
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, ax=ax4)
        ax4.set_title('Feature Correlation Heatmap')
        
        # 5. Countplot of test preparation course vs pass/fail
        ax5 = axes[1, 1]
        prep_target = pd.crosstab(self.df['test preparation course'], self.df['target'])
        prep_target.plot(kind='bar', ax=ax5, color=['red', 'green'])
        ax5.set_title('Test Preparation Course vs Pass/Fail')
        ax5.set_xlabel('Test Preparation Course')
        ax5.set_ylabel('Count')
        ax5.legend(['Fail', 'Pass'])
        
        # Remove the empty subplot
        axes[1, 2].remove()
        
        plt.tight_layout()
        plt.savefig('eda_visualizations.png', dpi=300, bbox_inches='tight')
        plt.close('all')
        
        return fig
    
    def train_models(self):
        """Train and evaluate 7 classification models"""
        print("\nTraining and evaluating models...")
        
        # Initialize models
        models = {
            'Logistic Regression': LogisticRegression(random_state=42, max_iter=1000),
            'Decision Tree': DecisionTreeClassifier(random_state=42),
            'Random Forest': RandomForestClassifier(random_state=42, n_estimators=100),
            'Gradient Boosting': GradientBoostingClassifier(random_state=42),
            'Naive Bayes': GaussianNB(),
            'SVM': SVC(random_state=42, probability=True),
            'XGBoost': xgb.XGBClassifier(random_state=42, eval_metric='logloss')
        }
        
        # Train and evaluate each model
        for name, model in models.items():
            print(f"\nTraining {name}...")
            
            # Train the model
            model.fit(self.X_train, self.y_train)
            
            # Make predictions
            y_pred = model.predict(self.X_test)
            
            # Calculate metrics
            accuracy = accuracy_score(self.y_test, y_pred)
            f1 = f1_score(self.y_test, y_pred)
            
            # Store model and scores
            self.models[name] = model
            self.model_scores[name] = {
                'accuracy': accuracy,
                'f1_score': f1
            }
            
            print(f"{name} - Accuracy: {accuracy:.4f}, F1 Score: {f1:.4f}")
        
        return self.models, self.model_scores
    
    def model_comparison_visualization(self):
        """Create bar chart comparing F1 scores"""
        print("\nCreating model comparison visualization...")
        
        model_names = list(self.model_scores.keys())
        f1_scores = [self.model_scores[name]['f1_score'] for name in model_names]
        
        plt.figure(figsize=(12, 6))
        bars = plt.bar(model_names, f1_scores, color='skyblue', edgecolor='black')
        plt.title('Model Comparison - F1 Scores')
        plt.xlabel('Models')
        plt.ylabel('F1 Score')
        plt.xticks(rotation=45)
        
        # Add value labels on bars
        for bar, score in zip(bars, f1_scores):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                    f'{score:.4f}', ha='center', va='bottom')
        
        plt.tight_layout()
        plt.savefig('model_comparison.png', dpi=300, bbox_inches='tight')
        plt.close('all')
        
        return plt.gcf()
    
    def select_best_model(self):
        """Select the best model based on F1 score"""
        print("\nSelecting best model...")
        
        # Find model with highest F1 score
        best_f1 = 0
        for name, scores in self.model_scores.items():
            if scores['f1_score'] > best_f1:
                best_f1 = scores['f1_score']
                self.best_model_name = name
                self.best_model = self.models[name]
        
        print(f"Best model: {self.best_model_name} with F1 Score: {best_f1:.4f}")
        
        # Retrain on full training set
        self.best_model.fit(self.X_train, self.y_train)
        
        return self.best_model, self.best_model_name
    
    def shap_explainability(self):
        """Generate SHAP explanations"""
        print("\nGenerating SHAP explanations...")
        
        if not HAS_SHAP:
            print("SHAP not available. Skipping SHAP analysis.")
            return None, None
        
        # Initialize SHAP explainer
        if self.best_model_name in ['SVM', 'XGBoost']:
            explainer = shap.Explainer(self.best_model, self.X_train)
        else:
            explainer = shap.Explainer(self.best_model, self.X_train)
        
        # Calculate SHAP values for test set
        shap_values = explainer(self.X_test)
        
        # Summary plot (bar chart)
        plt.figure(figsize=(10, 6))
        shap.summary_plot(shap_values, self.X_test, feature_names=self.feature_names, 
                         plot_type="bar", show=False)
        plt.title('SHAP Feature Importance (Summary Plot)')
        plt.tight_layout()
        plt.savefig('shap_summary.png', dpi=300, bbox_inches='tight')
        plt.close('all')
        
        # Force plot for first prediction
        plt.figure(figsize=(12, 4))
        shap.force_plot(explainer.expected_value, shap_values[0].values, 
                       self.X_test.iloc[0], feature_names=self.feature_names, 
                       matplotlib=True, show=False)
        plt.title('SHAP Force Plot - First Prediction')
        plt.tight_layout()
        plt.savefig('shap_force.png', dpi=300, bbox_inches='tight')
        plt.close('all')
        
        return explainer, shap_values
    
    def save_model_and_scaler(self):
        """Save the best model and scaler"""
        print("\nSaving model and scaler...")
        
        # Save the best model
        with open('student_model.pkl', 'wb') as f:
            pickle.dump(self.best_model, f)
        
        # Save the scaler
        with open('scaler.pkl', 'wb') as f:
            pickle.dump(self.scaler, f)
        
        # Save label encoders
        with open('label_encoders.pkl', 'wb') as f:
            pickle.dump(self.label_encoders, f)
        
        # Save feature names
        with open('feature_names.pkl', 'wb') as f:
            pickle.dump(self.feature_names, f)
        
        print("Model, scaler, and encoders saved successfully!")
    
    def print_model_summary(self):
        """Print comprehensive model performance summary"""
        print("\n" + "="*60)
        print("MODEL PERFORMANCE SUMMARY")
        print("="*60)
        
        for name, scores in self.model_scores.items():
            print(f"{name}:")
            print(f"  Accuracy: {scores['accuracy']:.4f}")
            print(f"  F1 Score: {scores['f1_score']:.4f}")
            print()
        
        print(f"BEST MODEL: {self.best_model_name}")
        print(f"Best F1 Score: {self.model_scores[self.best_model_name]['f1_score']:.4f}")
        print(f"Best Accuracy: {self.model_scores[self.best_model_name]['accuracy']:.4f}")
        print("="*60)

def main():
    """Main function to run the complete pipeline"""
    print("Starting Student Performance Prediction Pipeline...")
    
    # Initialize predictor
    predictor = StudentPerformancePredictor()
    
    # Load and explore data
    df = predictor.load_and_explore_data('StudentsPerformance.csv')
    if df is None:
        print("Failed to load data. Exiting.")
        return
    
    # Preprocess data
    X_train, X_test, y_train, y_test = predictor.preprocess_data()
    
    # Exploratory Data Analysis
    predictor.exploratory_data_analysis()
    
    # Train models
    models, model_scores = predictor.train_models()
    
    # Model comparison visualization
    predictor.model_comparison_visualization()
    
    # Select best model
    best_model, best_model_name = predictor.select_best_model()
    
    # SHAP explainability
    explainer, shap_values = predictor.shap_explainability()
    
    # Save model and scaler
    predictor.save_model_and_scaler()
    
    # Print summary
    predictor.print_model_summary()
    
    print("\nPipeline completed successfully!")
    print("Files generated:")
    print("- student_model.pkl")
    print("- scaler.pkl")
    print("- label_encoders.pkl")
    print("- feature_names.pkl")
    print("- eda_visualizations.png")
    print("- model_comparison.png")
    print("- shap_summary.png")
    print("- shap_force.png")

if __name__ == "__main__":
    main()
